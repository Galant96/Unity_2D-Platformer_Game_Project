﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public abstract class BaseAttackStrategy : MonoBehaviour, IAttackStrategy
{
	// Keyword abstract force any derived class to own implementation of that method
	public abstract void Attack();
}
