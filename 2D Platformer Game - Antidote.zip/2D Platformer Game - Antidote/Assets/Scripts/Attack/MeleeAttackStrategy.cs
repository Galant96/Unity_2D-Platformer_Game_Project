﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class MeleeAttackStrategy : BaseAttackStrategy
{
	[SerializeField]
	AudioClip zombieSFX;

	[SerializeField]
	private GameObject hurtEffect;

	[SerializeField]
	private float damage = 10f;

	public override void Attack()
	{
		AudioSource.PlayClipAtPoint(zombieSFX, Camera.main.transform.position);

		PlayParticleEffect();
		FindObjectOfType<Health>().TakeDamage(damage);
	}

	private void PlayParticleEffect()
	{
		Quaternion newRotation;

		float parentLocalScale = GetComponentInParent<Transform>().localScale.x;

		// Set the particle animation regarding to enemy local scale
		if (parentLocalScale == 1)
		{
			newRotation = Quaternion.Euler(0, 0, 0);
			hurtEffect.transform.rotation = newRotation;
		}
		else
		{
			newRotation = Quaternion.Euler(0, 0, 180f);
			hurtEffect.transform.rotation = newRotation;
		}

		hurtEffect.GetComponentInChildren<ParticleSystem>().Play();

	}




}
