﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class ShootStrategy : BaseAttackStrategy
{
	[SerializeField]
	private AudioClip shootSFX;

	[SerializeField]
	private GameObject bulletPrefab;

	[SerializeField]
	private Transform firePoint;

	[SerializeField]
	private float bulletSpeed = 10f;

	public override void Attack()
	{
		AudioSource.PlayClipAtPoint(shootSFX, Camera.main.transform.position);

		if (firePoint != null)
		{
			// Set a bullet prefab game object
			GameObject bullet = Instantiate(bulletPrefab, firePoint.position, firePoint.rotation) as GameObject;

			// Check in which direcetion player will shoot
			if (firePoint.parent.transform.localScale.x == 1)
			{
				// Move bullets left
				bullet.GetComponent<Rigidbody2D>().velocity = new Vector2(bulletSpeed, 1f);
			}
			else if (firePoint.parent.transform.localScale.x == -1)
			{
				// Move bullets right
				bullet.GetComponent<Rigidbody2D>().velocity = new Vector2(-bulletSpeed, 1f);
			}

			Destroy(bullet, 2f);
		}

	}
}
