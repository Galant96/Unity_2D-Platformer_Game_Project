﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class CameraFollow : MonoBehaviour
{
	[SerializeField]
	private Transform target; // potentialy player pos+

	[SerializeField, Header("Enable and set the maximum x value.")]
	private bool xMaxEnabled = false;
	public float xMaxValue = 0;

	[SerializeField, Header("Enable and set the minimum x value.")]
	private bool xMinEnabled = false;
	public float xMinValue = 0;

	[SerializeField, Header("Enable and set the maximum y value.")]
	private bool yMaxEnabled = false;
	public float yMaxValue = 0;

	[SerializeField, Header("Enable and set the minimum y value.")]
	private bool yMinEnabled = false;
	public float yMinValue = 0;

	private void Awake()
	{
		target = FindObjectOfType<Player>().transform;
	}


	private void FixedUpdate()
	{
		// Get the current pos of the target
		Vector3 currentTargetPos = target.position;

		// Get the current pos of the camera
		Vector3 currentCameraPos = transform.position;

		// Vertical
		if(yMinEnabled && yMaxEnabled)
		{
			currentTargetPos.y = Mathf.Clamp(target.position.y, yMinValue, yMaxValue);
		}
		else if(yMinEnabled)
		{
			currentTargetPos.y = Mathf.Clamp(target.position.y, yMinValue, target.position.y);
		}
		else if(yMaxEnabled)
		{
			currentTargetPos.y = Mathf.Clamp(target.position.y, target.position.y, yMaxValue);
		}

		// Horizontal
		if (xMinEnabled && xMaxEnabled)
		{
			currentTargetPos.x = Mathf.Clamp(target.position.x, xMinValue, xMaxValue);
		}
		else if (xMinEnabled)
		{
			currentTargetPos.x = Mathf.Clamp(target.position.x, xMinValue, target.position.x);
		}
		else if (xMaxEnabled)
		{
			currentTargetPos.x = Mathf.Clamp(target.position.x, target.position.x, xMaxValue);
		}

		currentCameraPos = new Vector3(currentTargetPos.x, currentTargetPos.y, transform.position.z);

		transform.position = currentCameraPos;

	}
}
