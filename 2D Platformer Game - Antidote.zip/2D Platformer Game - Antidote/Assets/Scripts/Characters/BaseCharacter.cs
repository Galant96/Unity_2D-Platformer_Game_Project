﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

// abstract class is a base class, while the other classes must inherit from it
// it shares begaviours, can use fields and interfaces
// it is helpful when checks or copying is needed
public abstract class BaseCharacter : MonoBehaviour
{
	protected IMoveStrategy moveStrategy;
	protected Animator animator;

	protected virtual void Start()
	{
		// get the move strategy of a character - every character ingerit from this class must have IMoveStrategy
		// Move() - the strategy of movement in the game
		moveStrategy = GetComponent<IMoveStrategy>();
		animator = GetComponent<Animator>();
	}

	protected abstract void Die();
}
