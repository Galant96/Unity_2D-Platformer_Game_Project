﻿using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Enemy : BaseCharacter, IPlayerSetter
{
	
	[SerializeField]
	private float visionRange = 1f;

	// how many point is the enemy worth
	[SerializeField] float points = 10f;

	[SerializeField]
	GameObject dieParticleEffect;

	private bool IsFacingRight;

	MoveEnemy moveEnemyScript;

	Transform target;

	// Start is called before the first frame update
	protected override void Start()
    {
		base.Start();
		moveEnemyScript = GetComponent<MoveEnemy>();

		// Set the position of the Player
		SetPlayer(FindObjectOfType<Player>().gameObject);
	}

	void Update()
    {
		
		// Get if the enemy is facing right
		IsFacingRight = moveEnemyScript.IsMoveRight;

		// Check the distance between enemy and player to see if player is class enough to attack
		float distanceToPlayer = Vector2.Distance(transform.position, target.position);
		// Debug.Log(distanceToPlayer);

		if (moveStrategy != null)
		{
			if(distanceToPlayer < visionRange)
			{
				// Flip the enemy while met the player and and start attack
				if(target.position.x > transform.position.x && IsFacingRight)
				{
					moveEnemyScript.Flip();
				}
				else if(target.position.x < transform.position.x && !IsFacingRight)
				{
					moveEnemyScript.Flip();

				}

				animator.SetTrigger("Attack");

			}
			else
			{
				moveStrategy.Move();

			}
		}		
	}

	// Get game object's position
	public void SetPlayer(GameObject gameObjectPlayer)
	{
		target = gameObjectPlayer.transform;
	}

	protected override void Die()
	{
		Destroy(gameObject);
	}

	private void OnCollisionEnter2D(Collision2D bullet)
	{
		if (bullet.gameObject.CompareTag("Bullet"))
		{
			// Destroy the bullet
			Destroy(bullet.gameObject);

			//  Wait for animations
			StartCoroutine(WaitForDie());
		}
	}

	IEnumerator WaitForDie()
	{
		dieParticleEffect.GetComponentInChildren<ParticleSystem>().Play();
		animator.SetTrigger("Die");
		yield return new WaitForSeconds(0.46f);
		
		// Update Score
		FindObjectOfType<GameManager>().CollectPoints(points);

		// Destroy enemy
		Die();
	}
}
