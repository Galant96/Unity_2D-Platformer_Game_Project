﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class EnemyAttack : BaseAttackStrategy
{
	public override void Attack()
	{
		throw new System.NotImplementedException();
	}
}
