﻿using UnityEngine;

// Interfaces - define methods/properties but not implementation
public interface IPlayerSetter
{
	// Method accept player dependecy game object
	// It allows the dependent to set and use the player dependency as they wish
	void SetPlayer(GameObject player);
}
