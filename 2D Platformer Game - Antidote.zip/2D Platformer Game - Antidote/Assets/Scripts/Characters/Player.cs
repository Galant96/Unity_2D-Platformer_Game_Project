﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Player : BaseCharacter
{
	Health health;
	public bool IsDead { get; private set; }

	// implememnt basic behaviour of the method
	protected override void Start()
	{
		base.Start();
		health = GetComponent<Health>();
		IsDead = false;
	}

	private void FixedUpdate()
	{
		// check if move strategy from BaseCharacter has been defined
		if((moveStrategy != null))
		{
			moveStrategy.Move();
		}

		// Make Player shoot
		if(Input.GetKeyDown(KeyCode.Mouse0))
		{
			animator.SetTrigger("Shoot");
		}

		if(health.Amount <= 0 && IsDead == false)
		{
			health.Amount = 0;
			animator.SetTrigger("Die");
			IsDead = true;

			Die();
		}

	}

	protected override void Die()
	{
		Debug.Log("You lost!");
	}

	// Receive notifiactaion of new game objects and register them
	public void RegisterSceneObjectItem(GameObject sceneObjectItem)
	{
		Debug.Log("Received notification");

		// Find all game objects that implement IPlayerSetter dependency on the sceneObjectItem
		IPlayerSetter[] playerSetters = sceneObjectItem.GetComponents<IPlayerSetter>();

		if(playerSetters != null)
		{
			// Loop through the player dependency
			foreach(IPlayerSetter playerSetter in playerSetters)
			{
				// Each inherited object pass this game object to SetPlayer function
				playerSetter.SetPlayer(gameObject);
			}
		}
	}
}
