﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Collectible : MonoBehaviour
{
	[SerializeField] AudioClip pickUpSFX;
	[SerializeField] int pointsForCollection = 100;

	private void OnTriggerEnter2D(Collider2D collision)
	{
		if(collision.CompareTag("Player"))
		{
			// Play sound effect
			AudioSource.PlayClipAtPoint(pickUpSFX, Camera.main.transform.position);
			// Add some points to the score
			FindObjectOfType<GameManager>().CollectPoints(pointsForCollection);
			FindObjectOfType<GameManager>().antidoteCounter -= 1;
			Destroy(gameObject);
		}
		
	}

}
