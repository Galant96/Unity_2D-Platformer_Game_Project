﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.Events;

// The EventSystem is responsible for processing and handling events in a Unity scene.
// A scene should only contain one EventSystem. 
// The EventSystem works in conjunction with a number of modules and mostly 
// just holds state and delegates functionality to specific, overrideable components.

[System.Serializable]
public class ObjectItemCreated : UnityEvent<GameObject> { };

[System.Serializable]
public class HealthChangeEvent : UnityEvent<float> { };

[System.Serializable]
public class HealthExpiredEvent : UnityEvent { };

[System.Serializable]
public class PlayerCollideEvent : UnityEvent<float> { };

