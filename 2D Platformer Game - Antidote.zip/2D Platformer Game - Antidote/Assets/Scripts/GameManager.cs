﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using TMPro;
using System;

public class GameManager : SingletonsPattern
{
	[SerializeField]
	TextMeshProUGUI playerHealthText;
	[SerializeField]
	TextMeshProUGUI scoreText;
	[SerializeField]
	TextMeshProUGUI timerText;
	[SerializeField]
	TextMeshProUGUI antidoteCounterText;

	[SerializeField]
	GameObject gameCanvasUI;

	[SerializeField]
	GameObject pauseMenuUI;

	[SerializeField]
	GameObject winUI;

	[SerializeField]
	GameObject lostUI;

	[SerializeField]
	private float timeToWait = 0.1f;

	Player player;

	LevelLoader levelLoader;

	private static float startTime = 0f;

	public int antidoteCounter { get; set; } = 0;

	public static float Score { get; private set; } = 0;

	public bool IsPaused { get; private set; }

	public static float PlayerHealthPercent { get; private set; }

	[SerializeField]
	private int numberAntidotesToFind = 3;

	// Scenes
	private int currentSceneIndex;
	private int previousSceneIndex;

	protected override void Awake()
	{
		base.Awake();

		antidoteCounter = numberAntidotesToFind;

		levelLoader = FindObjectOfType<LevelLoader>();
		previousSceneIndex = levelLoader.GetSceneIndex();
		currentSceneIndex = levelLoader.GetSceneIndex();

		player = FindObjectOfType<Player>();

		DisplayCurrentTime();
		CollectPoints(Score);
		DisplayCurrentPlayerHealth();
		DisplayAntidoteCounter();

	}

	public void CollectPoints(float points)
	{
		Score += points;
		Debug.Log("Score: " + Score);

		if(scoreText != null)
		{
			// Display current points
			scoreText.text = Score.ToString();
		}
		
	}

	private void DisplayCurrentPlayerHealth()
	{
		if (playerHealthText != null)
		{
			float currentHealth = player.GetComponent<Health>().Amount;

			if(currentHealth >= 0)
			{
				// Display current health
				playerHealthText.text = currentHealth.ToString();
			}
		}
	}

	private void DisplayCurrentTime()
	{
		if(timerText != null)
		{
			startTime += Time.deltaTime;

			string minutes = ((int)startTime / 60).ToString();
			string seconds = Mathf.Round(startTime % 60).ToString();

			timerText.text = minutes + ":" + seconds;
		}
		
	}

	private void DisplayAntidoteCounter()
	{
		if (antidoteCounterText != null)
		{
			antidoteCounterText.text = antidoteCounter.ToString();
		}

	}

	private void Update()
	{

		currentSceneIndex = levelLoader.GetSceneIndex();
		PrepareScene(currentSceneIndex);


		if (pauseMenuUI != null)
		{
			if (Input.GetKeyDown(KeyCode.Escape))
			{
				if (IsPaused)
				{
					Resume();
					pauseMenuUI.SetActive(false);
				}
				else
				{
					Pause();
					pauseMenuUI.SetActive(true);

				}
			}
		}

		if (winUI != null && lostUI != null)
		{
			// Check if player is dead
			if (player.IsDead && currentSceneIndex >= 2)
			{
				PlayerLost();
			}

			// Check if player win the level
			if (antidoteCounter <= 0)
			{
				PlayerWin();

			}
		}

	}

	private void PrepareScene(int currentSceneIndex)
	{
		if (currentSceneIndex >= 2)
		{
			player = FindObjectOfType<Player>();

			gameCanvasUI.SetActive(true);

			DisplayCurrentPlayerHealth();
			DisplayCurrentTime();
			DisplayAntidoteCounter();

		}
		else
		{
			gameCanvasUI.SetActive(false);
			winUI.SetActive(false);
			lostUI.SetActive(false);
			pauseMenuUI.SetActive(false);
		}
		

		if (currentSceneIndex > previousSceneIndex)
		{
			previousSceneIndex = currentSceneIndex;
			LoadNextLevel();
		}
	}

	private void LoadNextLevel()
	{
		player.transform.position = new Vector2(0, 0);
		winUI.SetActive(false);

		antidoteCounter = numberAntidotesToFind;
	}

	public void Restart()
	{
		player.transform.position = new Vector2(0, 0);
		lostUI.SetActive(false);
		pauseMenuUI.SetActive(false);

		antidoteCounter = numberAntidotesToFind;
		startTime = 0f;
		Score = 0;
	}

	private void PlayerWin()
	{
		winUI.SetActive(true);
	}

	private void PlayerLost()
	{
		lostUI.SetActive(true);
	}

	public void Pause()
	{
		Time.timeScale = 0f;
		IsPaused = true;
	}

	public void Resume()
	{
		Time.timeScale = 1f;
		IsPaused = false;
	}

}

