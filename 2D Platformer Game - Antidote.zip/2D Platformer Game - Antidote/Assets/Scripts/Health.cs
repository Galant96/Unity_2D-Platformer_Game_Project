﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Health : MonoBehaviour
{
	[SerializeField]
	private float amount = 100f;

	public float Amount
	{
		get { return amount; }
		set
		{
			amount = value;
		}
	}

	public float TakeDamage(float damage)
	{
		Debug.Log("Health: " + amount);
		return amount -= damage;
	}
}
