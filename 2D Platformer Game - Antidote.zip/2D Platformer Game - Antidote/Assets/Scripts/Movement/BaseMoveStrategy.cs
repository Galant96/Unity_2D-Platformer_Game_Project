﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public abstract class BaseMoveStrategy : MonoBehaviour, IMoveStrategy
{
	// game object's speed
	[SerializeField] protected float speed;

	protected Animator animator;
	protected new Rigidbody2D rigidbody2D;

	public abstract void Move();

	// Every character must have an animator component
	protected virtual void Start()
	{
		animator = GetComponent<Animator>();
		rigidbody2D = GetComponent<Rigidbody2D>();
	}
}
