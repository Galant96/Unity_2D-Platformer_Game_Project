﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class MoveEnemy : BaseMoveStrategy
{
	[SerializeField]
	public bool IsMoveRight = true;
	

	protected override void Start()
	{
		base.Start();
	}

	public override void Move()
	{
		Vector2 velocity = rigidbody2D.velocity;


		// If move right bool is true then move to the right
		if (IsMoveRight)
		{
			animator.SetBool("IsMove", true);

			
			velocity.x = -speed;
			rigidbody2D.velocity = velocity;

		}
		else if(!IsMoveRight)
		{
			animator.SetBool("IsMove", true);

			
			velocity = rigidbody2D.velocity;
			velocity.x = speed;
			rigidbody2D.velocity = velocity;
		}

	}

	// TO DO:
	// Move to player direction scipt 
	public void Flip()
	{
		// Get the character scale to flip a character
		Vector2 scale = transform.localScale;
		scale.x *= -1;
		transform.localScale = scale;
		IsMoveRight = !IsMoveRight;
	}

	private void OnTriggerEnter2D(Collider2D turnPoint)
	{
		if(turnPoint.gameObject.CompareTag("Turn Point"))
		{
			if(IsMoveRight)
			{
				// Flip the character right
				Flip();
			}
			else
			{
				// Flip the character left
				Flip();
			}
		}
	}

}
