﻿
public interface IMoveStrategy
{
	void Move();
}
