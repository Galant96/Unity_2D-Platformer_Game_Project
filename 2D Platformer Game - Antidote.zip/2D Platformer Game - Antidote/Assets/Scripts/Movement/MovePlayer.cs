﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class MovePlayer : BaseMoveStrategy
{
	// Sound Effects
	[SerializeField]
	AudioClip jumpSFX;

	[SerializeField] private float jumpForce = 1f;
	[SerializeField] private LayerMask platformLayerMask;

	private BoxCollider2D boxCollider2D;

	protected override void Start()
	{
		base.Start();

		boxCollider2D = GetComponent<BoxCollider2D>();
	}

	public override void Move()
	{

		// Get the character scale to flip a character
		Vector3 characterScale = transform.localScale;

		// Jump - apply the force to the rigidbody in the y-direction
		if (IsGrounded() && (Input.GetKeyDown(KeyCode.Space)|| Input.GetKeyDown(KeyCode.UpArrow)|| Input.GetKeyDown(KeyCode.W)))
		{
			AudioSource.PlayClipAtPoint(jumpSFX, Camera.main.transform.position);

			animator.SetTrigger("Jump");
			rigidbody2D.AddForce(new Vector2(0f, jumpForce));
		}
		else if (Input.GetKey(KeyCode.LeftArrow) || Input.GetKey(KeyCode.A))
		{
			MoveLeft(characterScale);
		}
		else if (Input.GetKey(KeyCode.RightArrow) || Input.GetKey(KeyCode.D))
		{
			MoveRight(characterScale);
		}
		else
		{
			animator.SetBool("isMove", false);
		}


	}

	private void MoveRight(Vector3 characterScale)
	{
		// Start animation
		animator.SetBool("isMove", true);

		// Flip character right
		characterScale.x = 1;
		transform.localScale = characterScale;

		// Get the current velocity
		Vector2 velocity = rigidbody2D.velocity;
		velocity.x = speed;
		rigidbody2D.velocity = velocity;
	}

	private void MoveLeft(Vector3 characterScale)
	{
		// Start animation
		animator.SetBool("isMove", true);

		// Flip the character left
		characterScale.x = -1;
		transform.localScale = characterScale;

		// Get the current velocity
		Vector2 velocity = rigidbody2D.velocity;
		velocity.x = -speed;
		rigidbody2D.velocity = velocity;
	}

	// Check that player touch a block
	private bool IsGrounded()
	{
														// Origin				// Size					// Angle	 // Direction // Distance	// Layer Mask
		RaycastHit2D raycastHit2D = Physics2D.BoxCast(boxCollider2D.bounds.center, boxCollider2D.bounds.size, 0f, Vector2.down, 0.1f, platformLayerMask);
		// Debug.Log(raycastHit2D.collider);
		return raycastHit2D.collider != null;
	}
}
