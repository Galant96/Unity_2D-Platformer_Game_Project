﻿using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public abstract class BaseSceneItem
{
	[SerializeField]
	protected GameObject prefab;

	// Property to read a prefab
	public GameObject Prefab
	{
		get { return prefab; }
	}

	// Create an item at position
	public GameObject CreateItem(Vector3 position)
	{
		return CreateGameObject(position, new Bounds());
	}

	// Creat an item within bounds
	public GameObject CreateItem(Bounds bounds)
	{
		return CreateGameObject(prefab.transform.position, bounds);
	}


	private GameObject CreateGameObject(Vector3 position, Bounds bounds)
	{
		// Instantiate a new game object from the prefab
		GameObject gameObject = MonoBehaviour.Instantiate(prefab) as GameObject;

		// Position the game object
		if (bounds.size == Vector3.zero)
		{
			gameObject.transform.position = position;
		}
		else
		{
			gameObject.transform.position = GetPos(position, bounds);
		}

		return gameObject;
	}


	protected abstract Vector3 GetPos(Vector3 currentPos, Bounds bounds);
}
