﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class RenderArea : MonoBehaviour
{
	private float _screenWidth;

	public float MinX { get; private set; }
	public float MaxX { get; private set; }

	// Constructor is a method a method when an object is created from the class
	// it uses parameters to set initial values for fields 
	public RenderArea(float screenWidth)
	{
		_screenWidth = screenWidth;
	}

	public void UpdateRendererArea(Vector3 playerPos)
	{
		MinX = playerPos.x - _screenWidth;
		MaxX = playerPos.x + _screenWidth;
	}
}

