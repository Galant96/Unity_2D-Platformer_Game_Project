﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class SceneController : MonoBehaviour
{
	[SerializeField] List<SceneBlockView> blockViews;

	[SerializeField] Transform player;

	RenderArea renderArea;

	List<GameObject> currentBlockViews;

	private void Awake()
	{
		player = FindObjectOfType<Player>().gameObject.transform;
	}
	// Start is called before the first frame update
	void Start()
	{
		SetRenderArea();
		currentBlockViews = new List<GameObject>();
	}

	private void FixedUpdate()
	{
		UpdateEnvironment();
	}

	void SetRenderArea()
	{
		// Set the height of the main camera
		float height = 2f * Camera.main.orthographicSize;
		float width = height * Camera.main.aspect;

		// Set initial value for the rendered area
		renderArea = new RenderArea(width);

	}

	void UpdateEnvironment()
	{
		float newBlockPos = 0f;
		bool isNewBlockNeeded = true;

		// Variable for storing a list of views to remove
		List<GameObject> viewsToRemove = new List<GameObject>();

		// Update my render min max pos based on player's pos
		renderArea.UpdateRendererArea(player.position);

		// Check if a current displayed block is in or outside the boundaries
		foreach (GameObject goBlockView in currentBlockViews)
		{
			ViewBounds viewBounds = goBlockView.GetComponent<ViewBounds>();

			// No more platforms needed
			if (viewBounds.MinX > renderArea.MaxX)
			{
				isNewBlockNeeded = false;
			}

			// Set new Pos
			float xPos = viewBounds.MaxX + viewBounds.Width * 0.5f;
			newBlockPos = Mathf.Max(newBlockPos, xPos);
		}

		// If new platforms needed, add them
		if (isNewBlockNeeded == true)
		{
			AddNewBlock(newBlockPos);
		}

	}

	void AddNewBlock(float xPos)
	{
		SceneBlockView blockView;
		int randomIndex = 0;

		if (this.blockViews.Count > 1)
		{
			randomIndex = Random.Range(0, this.blockViews.Count);
		}

		blockView = this.blockViews[randomIndex];

		// Create a new game object

		GameObject newBlockView = blockView.CreateItem(new Vector3(xPos, 0f, 0f));

		// Add a new block to the current list
		currentBlockViews.Add(newBlockView);

	}
}
