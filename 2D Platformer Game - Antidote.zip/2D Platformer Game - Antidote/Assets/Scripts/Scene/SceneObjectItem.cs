﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

[System.Serializable]

public class SceneObjectItem : BaseSceneItem
{
	[SerializeField] private int maxNumber = 1;
	[SerializeField] private float respawnInterval = 1.0f;
	[SerializeField] private bool randomPosY;

	public int MaxNumber
	{
		get { return maxNumber; }
	}

	public float RespawnInterval
	{
		get { return respawnInterval; }
	}

	public bool RandomPosY
	{
		get { return randomPosY; }
	}

	protected override Vector3 GetPos(Vector3 currentPos, Bounds bounds)
	{
		Vector3 pos;

		if (randomPosY)
		{
			// x position                  y position
			pos = new Vector3(Random.Range(bounds.min.x, bounds.max.x), Random.Range(bounds.min.y, bounds.max.y));
		}
		else
		{
			// x position                  y position
			pos = new Vector3(Random.Range(bounds.min.x, bounds.max.x), currentPos.y);
		}

		return pos;
	}
}