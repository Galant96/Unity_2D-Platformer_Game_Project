﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

// Attached to each block
// Gets the current block's size
public class ViewBounds : MonoBehaviour
{
	private Transform ceiling;

	private Transform floor;

	public float Width { get; private set; }

	private float Height
	{
		get { return ceiling.localPosition.y - floor.localPosition.y - 2f; }
	}

	public float MinX
	{
		get { return transform.position.x - (Width * 0.5f); }
	}

	public float MaxX
	{
		get { return MinX + Width; }
	}

	private void Awake()
	{
		// refferences to the block's floor and ceiling collider
		floor = transform.Find("Floor Collider");
		ceiling = transform.Find("Ceiling Collider");

		if (floor != null)
		{
			Width = floor.localScale.x;
		}
	}

	public Bounds GetBounds()
	{
		return new Bounds(transform.position, new Vector3(Width, Height));
	}
}
