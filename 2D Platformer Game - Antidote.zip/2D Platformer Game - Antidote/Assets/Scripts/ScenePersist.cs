﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class ScenePersist : MonoBehaviour
{
	private int startingSceneIndex;
	LevelLoader levelLoader;

	private void Awake()
	{
		int numScenePersist = FindObjectsOfType<ScenePersist>().Length;
		LevelLoader levelLoader = FindObjectOfType<LevelLoader>();

		if (numScenePersist > 1)
		{
			Destroy(gameObject);
		}
		else
		{
			DontDestroyOnLoad(gameObject);
		}
	}
	// Start is called before the first frame update
	void Start()
    {
		startingSceneIndex = levelLoader.GetSceneIndex();
    }

    // Update is called once per frame
    void Update()
    {
		int currentSceneIndex = levelLoader.GetSceneIndex();

		if (currentSceneIndex != startingSceneIndex)
		{
			Destroy(gameObject);
		}
	}
}
