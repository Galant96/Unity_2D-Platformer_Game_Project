﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public abstract class SingletonsPattern : MonoBehaviour
{
	public static SingletonsPattern Instance { get; private set; }

	protected virtual void Awake()
	{
		if (Instance == null)
		{
			Instance = this;
			DontDestroyOnLoad(gameObject);
		}
		else
		{
			Destroy(gameObject);
		}
	}

}
