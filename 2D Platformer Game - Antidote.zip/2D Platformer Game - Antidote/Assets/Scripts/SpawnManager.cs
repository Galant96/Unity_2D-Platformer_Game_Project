﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

[System.Serializable]
public class SpawnManager : MonoBehaviour
{
	[SerializeField]
	private List<GameObject> spawnPoints;

	// Create a list of available enemies
	[SerializeField]
	private List<GameObject> enemies;

	[SerializeField]
	private int enemyToSpawn;

	[SerializeField]
	float timeToSpawn;

	private bool IsSpawned = false;

	private void Awake()
	{
		spawnPoints = new List<GameObject>();
	}

	private void Start()
	{
		StartCoroutine(WaitAndSpawn());
	}

	IEnumerator WaitAndSpawn()
	{
		Debug.Log("Wait for loading full scene.");

		yield return new WaitForSeconds(timeToSpawn);

		spawnPoints.AddRange(GameObject.FindGameObjectsWithTag("Spawners"));
		// Spawn enemies at spawn position
		foreach (GameObject spawnPoint in spawnPoints)
		{
			Spawner spawner = spawnPoint.GetComponent<Spawner>();
			spawner.MaxNumberToSpawn = enemyToSpawn;
			spawner.Enemy = enemies[Random.Range(0, enemies.Count)];
			spawner.Spawn();
		}
	}

}
