﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Spawner: MonoBehaviour
{
	private int maxNumberToSpawn;
	private GameObject enemy;

	public int MaxNumberToSpawn
	{
		get { return maxNumberToSpawn; }
		set { maxNumberToSpawn = value; }
	}

	public GameObject Enemy
	{
		get { return enemy; }
		set { enemy = value; }
	}

	// Spawn enemies as many times as the maxNumberToSpawn is
	public void Spawn()
	{
		for(int i = 0; i < maxNumberToSpawn; i++)
		{
			Instantiate(enemy, transform.position, transform.rotation);
		}
	}

}
