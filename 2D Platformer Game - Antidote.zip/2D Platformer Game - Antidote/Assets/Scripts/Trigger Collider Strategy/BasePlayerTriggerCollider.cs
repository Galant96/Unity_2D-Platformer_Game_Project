﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.Events;

public abstract class BasePlayerTriggerCollider : MonoBehaviour, IPlayerSetter
{
	private PlayerCollideEvent onPlayerCollider;
	private string playerTag;
	protected abstract TriggerColliderTypes ColliderType{get;}
	protected abstract float GetCollisionReaction();

	public void SetPlayer(GameObject player)
	{
		playerTag = player.tag;
	}

	// Method for observer to subscribe to collide event
	public void AddPlayerColliderListener(TriggerColliderTypes colliderType, UnityAction<float> action)
	{
		if (colliderType == ColliderType)
		{
			// Initialise event
			if (onPlayerCollider == null)
				onPlayerCollider = new PlayerCollideEvent();

			// Add the observer method to send notification to
			onPlayerCollider.AddListener(action);
		}
	}

	private void OnDestroy()
	{
		// Clear any event listeners
		if (onPlayerCollider != null)
			onPlayerCollider.RemoveAllListeners();
	}

	private void OnTriggerEnter2D(Collider2D collision)
	{
		// Check if collided with player and respond if yes
		if (!string.IsNullOrEmpty(playerTag) && playerTag.Equals(collision.tag))
		{
			// Send event notification with damage / points
			if (onPlayerCollider != null)
				onPlayerCollider.Invoke(GetCollisionReaction());
		}
	}

}
