﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;


public class CollectibleTriggerCollider : BasePlayerTriggerCollider
{
	[SerializeField]
	int points;

	[SerializeField]
	const float dyingTime = 0f;

	protected override TriggerColliderTypes ColliderType
	{
		get { return TriggerColliderTypes.Collectible; }
	}

	protected override float GetCollisionReaction()
	{
		Destroy(gameObject, dyingTime);
		return points;
	}
}

